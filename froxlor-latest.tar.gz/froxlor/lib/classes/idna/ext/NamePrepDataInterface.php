<?php

namespace Mso\IdnaConvert;

interface NamePrepDataInterface
{
}
